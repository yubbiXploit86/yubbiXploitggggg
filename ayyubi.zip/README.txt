PERINGATAN: FILE ANDA TELAH DIENKRIPSI

Semua file Anda (dokumen, foto, video, database, dll.) telah dienkripsi dengan enkripsi RSA-2048 dan AES-128.

APA YANG TERJADI?

File Anda telah dikunci dengan algoritma enkripsi yang kuat. Anda TIDAK DAPAT mendekripsi file tanpa kunci privat khusus yang kami miliki.

BAGAIMANA MENDAPATKAN FILE KEMBALI?

1. Transfer tebusan sebesar Rp 3.000.000 (Tiga Juta Rupiah)
2. Kirim bukti transfer ke: retaabi58@gmail.com
3. Setelah pembayaran dikonfirmasi, kami akan mengirimkan:
   · Tool dekripsi
   · Kunci dekripsi khusus untuk sistem Anda
   · Petunjuk penggunaan

PENTING:

· JANGAN mencoba mendekripsi file sendiri
· JANGAN menghapus program ini
· JANGAN mematikan komputer
· JANGAN mengubah nama file
· JANGAN menggunakan software recovery pihak ketiga

Waktu Anda terbatas. Semakin lama menunggu, semakin besar risiko file hilang selamanya.

